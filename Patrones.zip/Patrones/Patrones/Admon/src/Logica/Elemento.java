package Logica;

public class Elemento {

}
