package utilitario;

public class Ingrediente {
	private String idIngrediente;
	private String nombreIngrediente;
	private double valorIngrediente;
	public String getIdIngrediente() {
		return idIngrediente;
	}
	public void setIdIngrediente(String idIngrediente) {
		this.idIngrediente = idIngrediente;
	}
	public String getNombreIngrediente() {
		return nombreIngrediente;
	}
	public void setNombreIngrediente(String nombreIngrediente) {
		this.nombreIngrediente = nombreIngrediente;
	}
	public double getValorIngrediente() {
		return valorIngrediente;
	}
	public void setValorIngrediente(double valorIngrediente) {
		this.valorIngrediente = valorIngrediente;
	}
	
	
}
