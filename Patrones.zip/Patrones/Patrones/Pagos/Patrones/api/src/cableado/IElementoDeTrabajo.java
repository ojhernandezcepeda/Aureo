package cableado;

public interface IElementoDeTrabajo {
	boolean gestionarElemento(String idElemento, int operacion);
}
