package cableado;

public interface IVentas {
	boolean gestioarVentas(String idFactura, String idEmpleado);
}
