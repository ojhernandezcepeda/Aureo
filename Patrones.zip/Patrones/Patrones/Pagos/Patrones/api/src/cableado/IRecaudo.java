package cableado;

public interface IRecaudo {
	boolean captarPago(String idFactura, double valor);
}
