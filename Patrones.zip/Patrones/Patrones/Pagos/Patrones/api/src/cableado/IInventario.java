package cableado;

public interface IInventario {
	boolean gestionarInventario(String idIngrediente, int operacion);
}
