package Logica;

import presentacion.PagosAbs;


public class AbstraccionRefinada extends PagosAbs{

}
