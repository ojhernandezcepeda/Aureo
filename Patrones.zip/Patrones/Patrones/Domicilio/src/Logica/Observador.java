package Logica;

public abstract class Observador {
	public void actualizar() {
		
	}
}
