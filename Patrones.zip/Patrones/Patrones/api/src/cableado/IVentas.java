package cableado;

public interface IVentas {
	boolean gestionarVentas();
}
