package cableado;

public interface IFondos {
	boolean gestionarFondos();
}
