package cableado;

public interface IElementoDeTrabajo {
	boolean gestionarElemento();
}
