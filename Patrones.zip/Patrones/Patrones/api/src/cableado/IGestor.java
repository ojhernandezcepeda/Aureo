package cableado;

public interface IGestor extends IVentas,IInventario,IElementoDeTrabajo,IFondos{
}
