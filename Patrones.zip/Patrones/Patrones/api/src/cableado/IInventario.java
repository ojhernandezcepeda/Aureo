package cableado;

public interface IInventario {
	boolean gestionarInventario();
}
