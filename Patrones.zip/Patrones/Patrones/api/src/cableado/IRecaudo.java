package cableado;

public interface IRecaudo {
	int captarPago(int idPlatillo, int valor, int cliente, String direccion);
}
